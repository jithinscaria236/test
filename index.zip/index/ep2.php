<?php $r1=$_REQUEST['t0'];
$a=$_REQUEST['t1'];
$c=$_REQUEST['t2'];
$d=$_REQUEST['t3'];
$e=$_REQUEST['t4']; $hra=(int)(($e*12)/100); $da=(int)(($e*2)/100);
$tsal=($hra+$da+$e)-($d); $con=mysql_connect("localhost","demo","jithin123");
$k=mysql_select_db("demo");
mysql_query("insert into employee values('$r1','$a','$hra','$da','$d','$e','$c','$tsal')");
$q=mysql_query("select * from  employee");
header("location:index.php"); ?>
