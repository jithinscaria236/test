<?php include "templates/header.php"; ?>

<ul>
	<li><a href="create.php"><strong>Create</strong></a> - Add a user</li>
	<li><a href="read.php"><strong>Read</strong></a> - Find a user</li>
	<li><a href="alluser.php"><strong>Read</strong></a> - All a user</li>
</ul>

<?php include "templates/footer.php"; ?>
